-- Phase 3: AI teacher (text classroom)
ALTER TABLE daily_activity ADD COLUMN teacher_turns smallint NOT NULL DEFAULT 0;
ALTER TABLE conversation_sessions ADD COLUMN last_turn_at timestamptz;
CREATE INDEX ix_conv_messages_session ON conversation_messages(session_id, seq);
