"""Deterministic stand-in for the AI teacher (tests and local demo only — never used in production)."""
from __future__ import annotations

from app.providers.base import Correction, NewWord, TeacherContext, TeacherTurn, TeacherUnavailable


class FakeTeacher:
    name = "fake"
    model = "fake-teacher"

    def __init__(self) -> None:
        self.calls: list[tuple[TeacherContext, str]] = []
        self.fail_next = False

    async def reply(self, context: TeacherContext, student_text: str) -> TeacherTurn:
        self.calls.append((context, student_text))
        if self.fail_next:
            self.fail_next = False
            raise TeacherUnavailable("simulated outage")
        low = student_text.lower()
        if "go school" in low:
            return TeacherTurn(
                text_en="Good try! Do you like your teacher?", text_ar="محاولة جيدة! هل تحب معلمك؟",
                correction=Correction(student_text, "I like to go to school.",
                                      "نقول to go to قبل school: I like to go to school."),
                repeat_after_me="I like to go to school.", new_words=(NewWord("teacher", "معلّم"),))
        if "hurt" in low or "scared" in low:
            return TeacherTurn(text_en="I am sorry. Please tell your mum or dad now.",
                               text_ar="أنا آسف. أخبر أمك أو أباك الآن من فضلك.", safety_concern=True)
        if "link" in low:  # model misbehaving: output must be cleaned
            return TeacherTurn(text_en="Visit https://evil.example now! What is your name?", text_ar="ما اسمك؟")
        name = student_text.split()[-1].strip(".!?") if "name is" in low else context.student_name
        return TeacherTurn(text_en=f"Very good, {name}! How old are you?",
                           text_ar=f"أحسنت يا {name}! كم عمرك؟", new_words=(NewWord("old", "عُمر"),))
