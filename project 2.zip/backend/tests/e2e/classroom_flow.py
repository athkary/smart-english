"""Browser E2E for the Phase 3 classroom (run while run_stack is up; uses the fake teacher)."""
from __future__ import annotations

import pathlib
import sys
import time

from playwright.sync_api import expect, sync_playwright

BASE = "http://127.0.0.1:5500/"
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2e3")
OUT.mkdir(parents=True, exist_ok=True)


def run(device: str, tag: str):
    with sync_playwright() as p:
        b = p.chromium.launch()
        page = b.new_context(**p.devices[device], locale="ar-SA").new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        shot = lambda n: page.screenshot(path=str(OUT / f"{tag}-{n}.png"), full_page=True)
        page.goto(BASE + "#/signup")
        page.get_by_label("اسمك").fill("أم أحمد")
        page.get_by_label("البريد الإلكتروني").fill(f"{tag}{int(time.time())}@example.com")
        page.get_by_label("كلمة المرور").fill("family-pass-2026")
        page.locator("#consent").check()
        page.get_by_role("button", name="إنشاء الحساب").click()
        page.get_by_role("link", name="إضافة طفل").first.click()
        page.get_by_label("اسم الطفل").fill("Ahmed")
        page.get_by_role("button", name="حفظ").click()
        page.get_by_role("button", name="ابدأ التعلم").click()
        d = page.get_by_role("dialog")
        d.get_by_label("رمز جديد").fill("2468")
        d.get_by_label("كلمة مرور الحساب").fill("family-pass-2026")
        d.get_by_role("button", name="تأكيد").click()
        page.evaluate("() => { window.__spoken = []; const o = speechSynthesis.speak.bind(speechSynthesis); speechSynthesis.speak = (u) => { window.__spoken.push(u.text); o(u); }; }")
        page.get_by_role("link", name="ابدأ الدرس مع معلمك").click()
        expect(page.get_by_role("heading", name="ماذا تريد أن تتعلم اليوم؟")).to_be_visible()
        shot("01-modes")
        page.get_by_role("button", name="محادثة للمبتدئين").click()
        expect(page.get_by_text("Hello! I am Emma. What is your name?")).to_be_visible()
        expect(page.get_by_text("مرحباً! أنا إيما. ما اسمك؟")).to_be_visible()
        page.get_by_label("اكتب بالإنجليزية…").fill("My name is Ahmed.")
        page.get_by_role("button", name="إرسال").click()
        expect(page.get_by_text("Very good, Ahmed! How old are you?")).to_be_visible()
        page.get_by_label("اكتب بالإنجليزية…").fill("I like go school")
        page.keyboard.press("Enter")
        expect(page.locator(".correction .corrected")).to_have_text("I like to go to school.")
        expect(page.locator(".repeat .repeat-en").last).to_have_text("I like to go to school.")
        assert any("Very good" in s for s in page.evaluate("window.__spoken")), "teacher reply was not spoken"
        shot("02-chat")
        page.get_by_role("button", name="إنهاء").click()
        expect(page.get_by_text("Great job!")).to_be_visible()
        expect(page.locator(".corr-row .corrected")).to_have_text("I like to go to school.")
        shot("03-summary")
        page.get_by_role("button", name="رجوع").click()
        expect(page.locator("h1.kid-title")).to_be_visible()
        assert not errors, errors
        b.close()
        print(f"✅ {device}: classroom flow passed")


if __name__ == "__main__":
    run("iPhone 13", "iphone")
    run("Pixel 7", "android")
