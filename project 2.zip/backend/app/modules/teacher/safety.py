"""Rule-based safety layer around the AI teacher (defence in depth; the prompt is the first layer).

Input: length cap, personal-data redaction (phones, emails, links), prompt-injection markers.
Output: strip links, cap length, fall back to a safe line if anything looks wrong.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.providers.base import Correction, NewWord, TeacherTurn

MAX_INPUT_CHARS = 300

_URL = re.compile(r"(https?://|www\.)\S+|\b[\w-]+\.(com|net|org|io|me|ly|gg|app)\b\S*", re.I)
_EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
# 7+ digits possibly separated by spaces/dashes (phone numbers), Western or Arabic-Indic digits
_PHONE = re.compile(r"(?:[+\d٠-٩][\s\-()]*){7,}")
_INJECTION = re.compile(r"(ignore (all|previous|your) (instructions|rules)|system prompt|you are now|"
                        r"تجاهل (التعليمات|القواعد))", re.I)
_ARABIC_LETTERS = re.compile(r"[؀-ۿ]")

REDACTED = "[…]"


@dataclass
class InputCheck:
    text: str
    flags: list[str] = field(default_factory=list)


def check_input(raw: str) -> InputCheck:
    text = " ".join(raw.split())[:MAX_INPUT_CHARS]
    flags: list[str] = []
    for name, pattern in (("email", _EMAIL), ("link", _URL), ("phone", _PHONE)):
        if pattern.search(text):
            flags.append("pii_" + name)
            text = pattern.sub(REDACTED, text)
    if _INJECTION.search(text):
        flags.append("prompt_injection")
    return InputCheck(text=text.strip(), flags=flags)


SAFE_FALLBACK = TeacherTurn(
    text_en="Let's keep practising English together! What is your favourite colour?",
    text_ar="لنواصل التدرّب على الإنجليزية معاً! ما لونك المفضّل؟",
    repeat_after_me="My favourite colour is blue.",
)


def _clean(s: str | None, limit: int) -> str:
    s = " ".join((s or "").split())
    s = _URL.sub("", s)
    s = _EMAIL.sub("", s)
    return s[:limit].strip()


def check_output(turn: TeacherTurn) -> tuple[TeacherTurn, list[str]]:
    flags: list[str] = []
    en = _clean(turn.text_en, 280)
    ar = _clean(turn.text_ar, 400)
    if not en or _ARABIC_LETTERS.search(en) and len(_ARABIC_LETTERS.findall(en)) > len(en) // 2:
        flags.append("bad_output")
        return SAFE_FALLBACK, flags
    if not ar:
        flags.append("missing_arabic")
    corr = turn.correction
    if corr is not None:
        o, c, x = _clean(corr.original, 200), _clean(corr.corrected, 200), _clean(corr.explanation_ar, 300)
        corr = Correction(o, c, x) if c and o.lower().strip(" .!?") != c.lower().strip(" .!?") else None
    words = tuple(NewWord(_clean(w.en, 40), _clean(w.ar, 60)) for w in turn.new_words[:3] if w.en and w.ar)
    if turn.safety_concern:
        flags.append("safety_concern")
    return TeacherTurn(text_en=en, text_ar=ar, correction=corr,
                       repeat_after_me=_clean(turn.repeat_after_me, 160) or None,
                       new_words=words, safety_concern=turn.safety_concern), flags
