"""Classroom: start a conversation, exchange turns with the AI teacher, end with a summary.

Enforces the parent's settings (allowed modes, daily time limit, transcript retention) and
per-child cost guards (turns per day) on the server.
"""
from __future__ import annotations

import json
import uuid
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from app.core.config import Settings
from app.core.http import AppError, not_found
from app.core.security import TokenClaims
from app.db.database import Database
from app.providers.base import ChatMessage, TeacherContext, TeacherLLM, TeacherTurn, TeacherUnavailable

from . import safety
from .prompts import MODES, PERSONAS, SCENARIOS, greeting

HISTORY_TURNS = 12          # messages of context sent to the model
SECONDS_CAP_PER_TURN = 90   # learning time credited per turn at most


class StartIn(BaseModel):
    mode: Literal["beginner", "guided", "free", "role_play"] = "beginner"
    scenario: str | None = None

    @model_validator(mode="after")
    def _scenario(self) -> "StartIn":
        if self.mode == "role_play" and self.scenario not in SCENARIOS:
            raise ValueError("unknown scenario")
        if self.mode != "role_play":
            self.scenario = None
        return self


class MessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


def _limit_reached() -> AppError:
    return AppError("daily_limit_reached", "Daily learning time is over. See you tomorrow!",
                    "انتهى وقت التعلّم لليوم. نراك غداً!", 403)


class ClassroomService:
    def __init__(self, db: Database, settings: Settings, llm: TeacherLLM | None) -> None:
        self.db, self.s, self.llm = db, settings, llm

    # ---------- helpers ----------
    async def _student(self, me: TokenClaims) -> dict:
        row = await self.db.fetchrow(
            """SELECT s.id, s.nickname, s.current_level::text AS level, s.show_arabic,
                      COALESCE(t.code, 'emma') AS teacher_code, t.id AS teacher_id,
                      ps.daily_limit_minutes, COALESCE(ps.free_conversation_enabled, true) AS free_ok,
                      COALESCE(ps.role_play_enabled, true) AS role_play_ok,
                      COALESCE(ps.store_transcripts, true) AS store_transcripts,
                      COALESCE(ps.transcript_retention_days, 90) AS retention_days,
                      COALESCE(da.learning_seconds, 0) AS seconds_today,
                      COALESCE(da.teacher_turns, 0) AS turns_today
               FROM students s
               LEFT JOIN teachers t ON t.id = s.preferred_teacher_id
               LEFT JOIN LATERAL (SELECT * FROM parent_settings p
                                  WHERE p.parent_id = s.parent_id AND (p.student_id = s.id OR p.student_id IS NULL)
                                  ORDER BY p.student_id NULLS LAST LIMIT 1) ps ON true
               LEFT JOIN daily_activity da ON da.student_id = s.id AND da.activity_date = current_date
               WHERE s.id = $1 AND s.parent_id = $2""", me.student_id, me.parent_id)
        if row is None:
            raise not_found()
        return row

    @staticmethod
    def _minutes_left(st: dict) -> int | None:
        if st["daily_limit_minutes"] is None:
            return None
        return max(0, st["daily_limit_minutes"] - st["seconds_today"] // 60)

    def _require_llm(self) -> TeacherLLM:
        if self.llm is None:
            raise AppError("teacher_unavailable", "The AI teacher is not available yet",
                           "المعلّم الذكي غير متاح بعد", 503)
        return self.llm

    # ---------- options ----------
    async def options(self, me: TokenClaims) -> dict:
        st = await self._student(me)
        modes = [{"code": c, "title_en": en, "title_ar": ar,
                  "allowed": not ((c == "free" and not st["free_ok"]) or (c == "role_play" and not st["role_play_ok"]))}
                 for c, (en, ar) in MODES.items()]
        scenarios = [{"code": c, "title_en": v[0], "title_ar": v[1]} for c, v in SCENARIOS.items()]
        return {"available": self.llm is not None, "teacher": st["teacher_code"],
                "teacher_name": PERSONAS.get(st["teacher_code"], PERSONAS["emma"])["name"],
                "modes": modes, "scenarios": scenarios, "minutes_left_today": self._minutes_left(st),
                "turns_left_today": max(0, self.s.teacher_daily_turns - st["turns_today"])}

    # ---------- start ----------
    async def start(self, me: TokenClaims, data: StartIn) -> dict:
        self._require_llm()
        st = await self._student(me)
        if (data.mode == "free" and not st["free_ok"]) or (data.mode == "role_play" and not st["role_play_ok"]):
            raise AppError("mode_not_allowed", "This activity is turned off by your parent",
                           "هذا النشاط مُغلق من قِبل ولي الأمر", 403)
        if self._minutes_left(st) == 0:
            raise _limit_reached()
        # housekeeping: purge transcripts past their retention date
        await self.db.execute("DELETE FROM conversation_messages WHERE expires_at IS NOT NULL AND expires_at < now()")
        await self.db.execute(
            "UPDATE conversation_sessions SET status = 'abandoned', ended_at = now() "
            "WHERE student_id = $1 AND status = 'active'", me.student_id)
        greet = greeting(st["teacher_code"], data.mode, data.scenario, st["nickname"])
        row = await self.db.fetchrow(
            """WITH s AS (INSERT INTO conversation_sessions(student_id, teacher_id, mode, scenario_code, provider_info,
                                                            last_turn_at)
                          VALUES ($1, (SELECT id FROM teachers WHERE code = $2), $3::conversation_mode, $4, $5::jsonb, now())
                          RETURNING id)
               INSERT INTO conversation_messages(session_id, seq, speaker, text_en, text_ar, correction, expires_at)
               SELECT id, 1, 'teacher', $6, $7, NULL, now() + make_interval(days => $8) FROM s RETURNING session_id""",
            me.student_id, st["teacher_code"], data.mode, data.scenario,
            json.dumps({"llm": getattr(self.llm, "name", None), "model": getattr(self.llm, "model", None)}),
            greet.text_en, greet.text_ar, self._retention(st))
        assert row is not None
        return {"session_id": row["session_id"], "teacher": st["teacher_code"],
                "teacher_name": PERSONAS.get(st["teacher_code"], PERSONAS["emma"])["name"],
                "mode": data.mode, "scenario": data.scenario, "show_arabic": st["show_arabic"],
                "greeting": greet.as_dict(), "minutes_left_today": self._minutes_left(st)}

    @staticmethod
    def _retention(st: dict) -> int:
        # Not storing transcripts => keep text only for the live session (1 day max), then purge.
        return st["retention_days"] if st["store_transcripts"] else 1

    # ---------- a turn ----------
    async def message(self, me: TokenClaims, session_id: uuid.UUID, data: MessageIn) -> dict:
        llm = self._require_llm()
        st = await self._student(me)
        sess = await self.db.fetchrow(
            "SELECT id, mode::text AS mode, scenario_code, status::text AS status, "
            "LEAST(EXTRACT(EPOCH FROM now() - COALESCE(last_turn_at, started_at))::int, $3) AS elapsed "
            "FROM conversation_sessions WHERE id = $1 AND student_id = $2",
            session_id, me.student_id, SECONDS_CAP_PER_TURN)
        if sess is None:
            raise not_found()
        if sess["status"] != "active":
            raise AppError("session_closed", "This lesson has ended", "انتهى هذا الدرس", 409)
        if self._minutes_left(st) == 0:
            raise _limit_reached()
        if st["turns_today"] >= self.s.teacher_daily_turns:
            raise AppError("daily_turns_reached", "You talked a lot today! Great job. See you tomorrow!",
                           "تحدّثت كثيراً اليوم! أحسنت. نراك غداً!", 429)

        checked = safety.check_input(data.text)
        if not checked.text:
            raise AppError("empty_message", "Please write something", "اكتب شيئاً من فضلك", 422)
        history_rows = await self.db.fetch(
            "SELECT speaker::text AS speaker, text_en FROM conversation_messages WHERE session_id = $1 "
            "ORDER BY seq DESC LIMIT $2", session_id, HISTORY_TURNS)
        history = tuple(ChatMessage("teacher" if r["speaker"] == "teacher" else "student", r["text_en"])
                        for r in reversed(history_rows))
        ctx = TeacherContext(teacher_code=st["teacher_code"], student_name=st["nickname"], mode=sess["mode"],
                             student_level=st["level"], show_arabic=st["show_arabic"],
                             scenario_code=sess["scenario_code"], history=history)
        try:
            turn: TeacherTurn = await llm.reply(ctx, checked.text)
        except TeacherUnavailable:
            raise AppError("teacher_busy", "The teacher is busy, please try again",
                           "المعلّم مشغول الآن، حاول مرة أخرى", 502) from None
        turn, out_flags = safety.check_output(turn)

        correction = turn.as_dict()["correction"]
        retention = self._retention(st)
        await self.db.execute(
            """WITH n AS (SELECT COALESCE(max(seq), 0) AS m FROM conversation_messages WHERE session_id = $1),
               a AS (INSERT INTO conversation_messages(session_id, seq, speaker, text_en, safety_flags, expires_at)
                     SELECT $1, m + 1, 'student', $2, string_to_array($3, ','), now() + make_interval(days => $9) FROM n),
               b AS (INSERT INTO conversation_messages(session_id, seq, speaker, text_en, text_ar, correction,
                                                       safety_flags, expires_at)
                     SELECT $1, m + 2, 'teacher', $4, $5, $6::jsonb, string_to_array($7, ','), now() + make_interval(days => $9) FROM n),
               u AS (UPDATE conversation_sessions SET turn_count = turn_count + 1, last_turn_at = now()
                     WHERE id = $1)
               INSERT INTO daily_activity(student_id, activity_date, learning_seconds, conversation_seconds, teacher_turns)
               VALUES ($8, current_date, $10, $10, 1)
               ON CONFLICT (student_id, activity_date) DO UPDATE SET
                 learning_seconds = daily_activity.learning_seconds + EXCLUDED.learning_seconds,
                 conversation_seconds = daily_activity.conversation_seconds + EXCLUDED.conversation_seconds,
                 teacher_turns = daily_activity.teacher_turns + 1""",
            session_id, checked.text, _pg_array(checked.flags), turn.text_en, turn.text_ar,
            json.dumps(correction, ensure_ascii=False) if correction else None, _pg_array(out_flags),
            me.student_id, retention, int(sess["elapsed"] or 0))
        st["seconds_today"] += int(sess["elapsed"] or 0)
        return {"student": {"text": checked.text, "redacted": any(f.startswith("pii_") for f in checked.flags)},
                "teacher": turn.as_dict(), "minutes_left_today": self._minutes_left(st)}

    # ---------- end ----------
    async def end(self, me: TokenClaims, session_id: uuid.UUID) -> dict:
        rows = await self.db.fetch(
            """SELECT m.correction FROM conversation_messages m JOIN conversation_sessions s ON s.id = m.session_id
               WHERE m.session_id = $1 AND s.student_id = $2 AND m.correction IS NOT NULL ORDER BY m.seq""",
            session_id, me.student_id)
        summary = {"corrections": [r["correction"] if isinstance(r["correction"], dict) else json.loads(r["correction"])
                                   for r in rows]}
        row = await self.db.fetchrow(
            """UPDATE conversation_sessions SET status = 'completed', ended_at = now(), summary = $3::jsonb
               WHERE id = $1 AND student_id = $2 AND status = 'active' RETURNING turn_count""",
            session_id, me.student_id, json.dumps(summary, ensure_ascii=False))
        if row is None:
            exists = await self.db.fetchrow("SELECT 1 AS x FROM conversation_sessions WHERE id = $1 AND student_id = $2",
                                            session_id, me.student_id)
            if exists is None:
                raise not_found()
            raise AppError("session_closed", "This lesson has ended", "انتهى هذا الدرس", 409)
        st = await self._student(me)
        if not st["store_transcripts"]:
            await self.db.execute("DELETE FROM conversation_messages WHERE session_id = $1", session_id)
        return {"turns": row["turn_count"], "corrections": summary["corrections"]}


def _pg_array(items: list[str]) -> str:
    """Comma-joined flags for string_to_array($n, ',') (flags are internal identifiers)."""
    return ",".join(items)
