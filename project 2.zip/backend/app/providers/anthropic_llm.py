"""Claude (Anthropic Messages API) adapter for the TeacherLLM interface.

Uses forced tool use to get a structured bilingual reply. Standard library HTTP (run in a
worker thread) so there is no extra dependency; the transport is injectable for tests.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import urllib.error
import urllib.request
from typing import Any, Callable

from app.modules.teacher.prompts import REPLY_TOOL, system_prompt
from app.providers.base import Correction, NewWord, TeacherContext, TeacherTurn, TeacherUnavailable

log = logging.getLogger("smart_english.llm")

API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"

Transport = Callable[[str, dict[str, str], bytes, float], tuple[int, bytes]]


def urllib_transport(url: str, headers: dict[str, str], body: bytes, timeout: float) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - fixed https URL
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()


def build_messages(ctx: TeacherContext, student_text: str) -> list[dict[str, Any]]:
    """Alternating user/assistant history ending with the new student message."""
    msgs: list[dict[str, Any]] = []
    for m in ctx.history:
        role = "assistant" if m.role == "teacher" else "user"
        if msgs and msgs[-1]["role"] == role:
            msgs[-1]["content"] += "\n" + m.text
        else:
            msgs.append({"role": role, "content": m.text})
    if msgs and msgs[0]["role"] == "assistant":
        msgs.insert(0, {"role": "user", "content": "(The lesson starts.)"})
    if msgs and msgs[-1]["role"] == "user":
        msgs[-1]["content"] += "\n" + student_text
    else:
        msgs.append({"role": "user", "content": student_text})
    return msgs


def parse_reply(payload: dict[str, Any]) -> TeacherTurn:
    for block in payload.get("content", []):
        if block.get("type") == "tool_use" and block.get("name") == REPLY_TOOL["name"]:
            data = block.get("input") or {}
            corr = data.get("correction")
            correction = None
            if isinstance(corr, dict) and corr.get("corrected"):
                correction = Correction(str(corr.get("original", "")), str(corr["corrected"]),
                                        str(corr.get("explanation_ar", "")))
            words = tuple(NewWord(str(w.get("en", "")), str(w.get("ar", "")))
                          for w in (data.get("new_words") or []) if isinstance(w, dict))
            rep = data.get("repeat_after_me")
            return TeacherTurn(text_en=str(data.get("reply_en", "")), text_ar=str(data.get("reply_ar", "")),
                               correction=correction, repeat_after_me=str(rep) if rep else None,
                               new_words=words, safety_concern=bool(data.get("safety_concern")))
    raise TeacherUnavailable("model did not return a teacher_reply tool call")


class AnthropicTeacher:
    name = "anthropic"

    def __init__(self, api_key: str, model: str, *, max_tokens: int = 500, timeout: float = 25.0,
                 transport: Transport = urllib_transport) -> None:
        if not api_key:
            raise ValueError("api_key required")
        self._key, self.model, self._max_tokens, self._timeout = api_key, model, max_tokens, timeout
        self._transport = transport

    def _request_body(self, ctx: TeacherContext, student_text: str) -> dict[str, Any]:
        return {
            "model": self.model,
            "max_tokens": self._max_tokens,
            "system": system_prompt(ctx),
            "messages": build_messages(ctx, student_text),
            "tools": [REPLY_TOOL],
            "tool_choice": {"type": "tool", "name": REPLY_TOOL["name"]},
            "temperature": 0.6,
        }

    async def reply(self, context: TeacherContext, student_text: str) -> TeacherTurn:
        body = json.dumps(self._request_body(context, student_text), ensure_ascii=False).encode()
        headers = {"x-api-key": self._key, "anthropic-version": API_VERSION, "content-type": "application/json"}
        start = time.perf_counter()
        for attempt in range(2):  # one retry on overload / transient network errors
            try:
                status, raw = await asyncio.to_thread(self._transport, API_URL, headers, body, self._timeout)
            except (OSError, TimeoutError) as exc:
                log.warning("llm transport error", extra={"fields": {"error": type(exc).__name__}})
                status, raw = 0, b""
            if status == 200:
                payload = json.loads(raw)
                log.info("llm reply", extra={"fields": {
                    "ms": round((time.perf_counter() - start) * 1000),
                    "input_tokens": payload.get("usage", {}).get("input_tokens"),
                    "output_tokens": payload.get("usage", {}).get("output_tokens")}})
                return parse_reply(payload)
            if status in (0, 429, 500, 502, 503, 529) and attempt == 0:
                await asyncio.sleep(1.0)
                continue
            detail = raw[:300].decode(errors="replace") if raw else ""
            log.error("llm error", extra={"fields": {"status": status, "detail": detail}})
            raise TeacherUnavailable(f"LLM HTTP {status}")
        raise TeacherUnavailable("LLM unavailable")
