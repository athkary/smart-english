// On-device speech via the browser's built-in Web Speech API (free, works on iPhone & Android).
// Phase 4 will add listening (speech recognition) for the voice classroom.

export function speechSupported() {
  return "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
}

function englishVoice() {
  const voices = window.speechSynthesis.getVoices();
  return voices.find((v) => v.lang === "en-US" && /samantha|google us english|aria|jenny/i.test(v.name))
      || voices.find((v) => v.lang === "en-US")
      || voices.find((v) => v.lang?.startsWith("en"));
}

export function speak(text, { slow = false } = {}) {
  const synth = window.speechSynthesis;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-US";
  const voice = englishVoice();
  if (voice) u.voice = voice;
  u.rate = slow ? 0.7 : 0.9;
  synth.speak(u);
  return u;
}

if (speechSupported()) window.speechSynthesis.getVoices(); // warm up the voice list (Chrome loads it async)

// Free on-device/browser speech recognition (Chrome on Android, Safari on iOS 14.5+).
export function recognitionSupported() {
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

/** Listen once in English. Resolves with the transcript ("" if nothing was heard). */
export function listenOnce({ onInterim } = {}) {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  return new Promise((resolve, reject) => {
    const rec = new Rec();
    rec.lang = "en-US";
    rec.interimResults = true;
    rec.maxAlternatives = 1;
    let finalText = "";
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) finalText += r[0].transcript; else interim += r[0].transcript;
      }
      onInterim && onInterim(finalText + interim);
    };
    rec.onerror = (e) => (e.error === "no-speech" || e.error === "aborted" ? resolve("") : reject(e));
    rec.onend = () => resolve(finalText.trim());
    window.speechSynthesis && window.speechSynthesis.cancel();
    rec.start();
    listenOnce.stop = () => rec.stop();
  });
}
