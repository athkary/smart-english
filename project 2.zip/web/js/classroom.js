// Classroom: talk with the AI teacher (text + free browser voice).
import { api } from "./api.js";
import { t, getLang, errorText } from "./i18n.js";
import { h, en, ar, mount, toast, busy } from "./ui.js";
import { speak, speechSupported, recognitionSupported, listenOnce } from "./speech.js";

const AUTO_SPEAK_KEY = "se.autoSpeak";
const autoSpeak = { get: () => { try { return localStorage.getItem(AUTO_SPEAK_KEY) !== "0"; } catch { return true; } },
                    set: (v) => { try { localStorage.setItem(AUTO_SPEAK_KEY, v ? "1" : "0"); } catch { /* */ } } };

function say(text, slow = false) {
  if (!speechSupported()) return toast(t("speech.unsupported"), "warn");
  speak(text, { slow });
}

const listenBtn = (text, label = t("child.listen")) =>
  h("button", { class: "btn-icon sm", type: "button", "aria-label": `${label}: ${text}`, onclick: () => say(text) }, "🔊");

// ---------- step 1: choose an activity ----------
export async function viewClassroom(root, { onExit }) {
  mount(root, h("main", { class: "page" }, h("div", { class: "spinner" })));
  let opts, me;
  try { [opts, me] = await Promise.all([api.child.classroomOptions(), api.child.me()]); }
  catch (e) { return mount(root, h("main", { class: "page" }, h("p", { class: "form-error" }, errorText(e)))); }
  if (!opts.available) return onExit();

  const scenarioGrid = h("div", { class: "scenario-grid", hidden: true },
    opts.scenarios.map((s) => h("button", { type: "button", class: "scenario", onclick: () => begin("role_play", s.code) },
      h("strong", {}, en(s.title_en)), me.show_arabic && h("small", {}, ar(s.title_ar)))));

  const modeIcons = { beginner: "🌱", guided: "🧩", free: "💬", role_play: "🎭" };
  const modeCards = opts.modes.map((m) => h("button", {
    type: "button", class: "mode-card", disabled: !m.allowed,
    onclick: () => (m.code === "role_play" ? (scenarioGrid.hidden = !scenarioGrid.hidden) : begin(m.code)),
  }, h("span", { class: "mode-icon", "aria-hidden": "true" }, modeIcons[m.code]),
     h("strong", {}, getLang() === "ar" ? m.title_ar : m.title_en),
     !m.allowed && h("small", {}, t("class.mode_off"))));

  async function begin(mode, scenario) {
    try {
      const s = await api.child.startClass(scenario ? { mode, scenario } : { mode });
      chat(root, s, me, onExit);
    } catch (e) { toast(errorText(e), "error"); }
  }

  mount(root,
    h("header", { class: "topbar kid" },
      h("button", { class: "btn btn-ghost btn-sm", type: "button", onclick: onExit }, "‹ ", t("back")),
      h("div", { class: "brand" }, h("span", { class: `teacher-face sm t-${opts.teacher}` }, opts.teacher_name[0]),
        h("span", {}, opts.teacher_name))),
    h("main", { class: "page" },
      h("h1", {}, t("class.choose")),
      opts.minutes_left_today != null && h("p", { class: "muted" }, `⏱ ${opts.minutes_left_today} ${t("child.minutes_left")}`),
      h("div", { class: "mode-grid" }, modeCards),
      scenarioGrid));
}

// ---------- step 2: the conversation ----------
function chat(root, session, me, onExit) {
  const showAr = session.show_arabic;
  const list = h("div", { class: "chat", role: "log", "aria-live": "polite" });
  const input = h("input", { type: "text", maxlength: 300, dir: "ltr", lang: "en", autocomplete: "off",
                             placeholder: t("class.placeholder"), "aria-label": t("class.placeholder"), enterkeyhint: "send" });
  const send = h("button", { class: "btn btn-primary", type: "submit" }, t("class.send"));
  const status = h("p", { class: "muted small chat-status" },
    session.minutes_left_today != null ? `⏱ ${session.minutes_left_today} ${t("child.minutes_left")}` : "");
  const speakToggle = h("input", { type: "checkbox", checked: autoSpeak.get(), onchange: (e) => autoSpeak.set(e.target.checked) });
  let ended = false;

  const mic = recognitionSupported() && h("button", {
    class: "btn-mic", type: "button", "aria-label": t("class.mic"), onclick: async () => {
      if (mic.classList.contains("listening")) return listenOnce.stop && listenOnce.stop();
      mic.classList.add("listening");
      try {
        const heard = await listenOnce({ onInterim: (txt) => (input.value = txt) });
        if (heard) { input.value = heard; form.requestSubmit(); }
      } catch { toast(t("class.mic_error"), "warn"); }
      finally { mic.classList.remove("listening"); }
    } }, "🎤");

  function teacherBubble(turn) {
    const b = h("div", { class: "bubble teacher" },
      h("div", { class: "line" }, en(turn.text_en, "say-en"), listenBtn(turn.text_en)),
      showAr && turn.text_ar && h("p", { class: "say-ar" }, ar(turn.text_ar)),
      turn.correction && h("div", { class: "correction" },
        h("p", { class: "label" }, "✏️ ", t("class.correct_is")),
        h("div", { class: "line" }, en(turn.correction.corrected, "corrected"), listenBtn(turn.correction.corrected)),
        showAr && turn.correction.explanation_ar && h("p", { class: "small" }, ar(turn.correction.explanation_ar))),
      turn.repeat_after_me && h("div", { class: "repeat" },
        h("p", { class: "label" }, "🔁 ", t("class.repeat")),
        h("div", { class: "line" }, en(turn.repeat_after_me, "repeat-en"), listenBtn(turn.repeat_after_me))),
      turn.new_words && turn.new_words.length > 0 && h("div", { class: "chips" },
        turn.new_words.map((w) => h("button", { class: "chip", type: "button", onclick: () => say(w.en, true) },
          en(w.en), showAr && " · ", showAr && ar(w.ar)))));
    list.append(b);
    b.scrollIntoView({ behavior: "smooth", block: "end" });
    if (autoSpeak.get() && speechSupported()) speak(turn.text_en);
  }

  function studentBubble(text) {
    const b = h("div", { class: "bubble student" }, en(text));
    list.append(b);
    b.scrollIntoView({ behavior: "smooth", block: "end" });
  }

  const form = h("form", { class: "composer" }, mic, input, send);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text || ended) return;
    input.value = "";
    studentBubble(text);
    const typing = h("div", { class: "bubble teacher typing", "aria-label": t("class.thinking") }, h("span"), h("span"), h("span"));
    list.append(typing);
    typing.scrollIntoView({ block: "end" });
    busy(send, true);
    try {
      const r = await api.child.say(session.session_id, text);
      typing.remove();
      teacherBubble(r.teacher);
      if (r.minutes_left_today != null) status.textContent = `⏱ ${r.minutes_left_today} ${t("child.minutes_left")}`;
    } catch (ex) {
      typing.remove();
      toast(errorText(ex), "error");
      if (ex.code === "daily_limit_reached" || ex.code === "daily_turns_reached" || ex.code === "session_closed") finish();
    } finally { busy(send, false); input.focus(); }
  });

  async function finish() {
    if (ended) return;
    ended = true;
    window.speechSynthesis && window.speechSynthesis.cancel();
    let summary = { turns: 0, corrections: [] };
    try { summary = await api.child.endClass(session.session_id); } catch { /* already closed */ }
    mount(root, h("main", { class: "page" },
      h("div", { class: "card summary" },
        h("div", { class: "hero-art", "aria-hidden": "true" }, "🌟"),
        h("h1", {}, en("Great job!"), showAr && h("span", { class: "sub" }, ar(" أحسنت!"))),
        h("p", {}, `${t("class.turns")}: ${summary.turns}`),
        summary.corrections.length > 0 && h("div", {},
          h("h2", {}, t("class.learned")),
          summary.corrections.map((c) => h("div", { class: "line corr-row" }, en(c.corrected, "corrected"), listenBtn(c.corrected)))),
        h("button", { class: "btn btn-primary btn-lg", type: "button", onclick: onExit }, t("class.done")))));
  }

  mount(root,
    h("header", { class: "topbar kid" },
      h("div", { class: "brand" }, h("span", { class: `teacher-face sm t-${session.teacher}` }, session.teacher_name[0]),
        h("span", {}, session.teacher_name)),
      h("div", { class: "topbar-actions" },
        h("label", { class: "auto-speak", title: t("class.auto_speak") }, speakToggle, "🔈"),
        h("button", { class: "btn btn-ghost btn-sm", type: "button", onclick: finish }, t("class.end")))),
    h("main", { class: "page chat-page" }, list, status, form));
  teacherBubble(session.greeting);
  input.focus();
}
